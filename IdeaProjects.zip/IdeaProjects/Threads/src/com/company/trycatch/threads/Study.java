package com.company.trycatch.threads;

public class Study {
    public static void main(String[] args) {
        
    }
}
