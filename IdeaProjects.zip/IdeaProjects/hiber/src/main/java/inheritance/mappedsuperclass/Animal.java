package inheritance.mappedsuperclass;

import javax.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class Animal {

    public Animal(String name) {
        this.name = name;
    }

    public Animal() {
    }

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
