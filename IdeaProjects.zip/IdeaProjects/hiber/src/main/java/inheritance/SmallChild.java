package inheritance;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("Small child")
public class SmallChild extends Man {

    private int lengthOfTail;

    public int getLengthOfTail() {
        return lengthOfTail;
    }

    public void setLengthOfTail(int lengthOfTail) {
        this.lengthOfTail = lengthOfTail;
    }

    public static void main(String[] args) {

    }

}
