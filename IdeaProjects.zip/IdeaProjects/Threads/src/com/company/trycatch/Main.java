package com.company.trycatch;

import java.io.IOException;

public class Main {


    public void print() throws RuntimeException, FirstException {
        try {
            if (1 == 2) {
                throw new FirstException();
            } else {
                throw new IOException();
            }

//            if (5 == 6) {
//                throw new ();
//            }


        } catch (RuntimeException | IOException sqlException) {
            throw new RuntimeException();
        }
    }

    public static void main(String[] args) {

    }
}

class FirstException extends Exception {

}

class SecondException extends Exception {

}
