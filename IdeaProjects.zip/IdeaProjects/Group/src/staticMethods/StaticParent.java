package staticMethods;

public class StaticParent {
    public static void print(){
        System.out.println("Parent: inside print");
    }
}
