package learninheritance;


public interface Studyable extends Runnable {
//    default void learnBooks() {
//        System.out.println("");
//    }

    void learnBooks();
//    public void learnBooks();
//    public abstract void learnBooks();


}
