package test;

public class Study2 {

    public static void main(String[] args) {
        Study study = new Study();
        study.print();
    }
}
