package country;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.io.Serializable;

@Embeddable
public class City implements Serializable {

    @Column(name = "CountOfCitizens")
    private int countOfStreets;

    @Column(name = "NameOfCity")
    private String name;

    @Column(name = "State")
    @Enumerated(EnumType.STRING)
    private State state;

    public City() {
    }

    public City(Integer countOfStreets, String name, State state) {
        this.countOfStreets = countOfStreets;
        this.name = name;
        this.state = state;
    }

    public int getCountOfStreets() {
        return countOfStreets;
    }

    public void setCountOfStreets(int countOfStreets) {
        this.countOfStreets = countOfStreets;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }
}
