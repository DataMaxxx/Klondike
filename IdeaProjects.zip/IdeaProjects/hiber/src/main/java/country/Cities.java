package country;

public enum Cities {
    PAVLOGRAD, DNEPR
}
