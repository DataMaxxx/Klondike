package relationship.onetoone;

import javax.persistence.*;

@Entity
@Table(name = "Student")
@SequenceGenerator(name = "STUDENT_SEQUENCE", sequenceName = "STUDENT_SEQUENCE", allocationSize = 1, initialValue = 0)
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "STUDENT_SEQUENCE")
    private int id;

    @Column(name = "Student_name")
    private String name;

    @OneToOne(cascade = CascadeType.ALL)
    @PrimaryKeyJoinColumn
    private Address address;

    public Student(String name) {
        this.name = name;
    }

    public Student() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public static void main(String[] args) {
        EntityManagerFactory managerFactory = Persistence.createEntityManagerFactory("sample");
        EntityManager entityManager = managerFactory.createEntityManager();
        EntityTransaction transaction = entityManager.getTransaction();
        transaction.begin();
        Student student = new Student("Students");
        Address address = new Address("Address");
        student.setAddress(address);
        entityManager.persist(student);
//        entityManager.remove(student);
        transaction.commit();
        entityManager.close();
    }
}
