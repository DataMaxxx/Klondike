package country;

public enum State {
    DNEPR, KIEV
}
