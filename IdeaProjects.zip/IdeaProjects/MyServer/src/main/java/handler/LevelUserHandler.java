package handler;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import domain.User;
import org.apache.log4j.Logger;
import storage.Storage;

import java.io.IOException;
import java.util.List;


/*
 * The class is handler for GET request for getting information about users on specific level
 */

public class LevelUserHandler extends QueryHandler {

    private static final Logger logger = Logger.getLogger(LevelUserHandler.class);
    public static final String METHOD_GET = "GET";

    @Override
    public void handle(HttpExchange httpExchange) throws IOException {
        setHttpExchange(httpExchange);
        if (validateRequestMethod(METHOD_GET)) {
            int leveId = getParameterFromQuery();
            List<User> usersFromOneLevels = Storage.getUsersFromOneLevel(leveId);
            logger.info("Get information for user with id = " + usersFromOneLevels.iterator().next().getUserId() +
                    " on level " + leveId);
            convertFromListToStringAndSendResponse(usersFromOneLevels);
        } else {
            responseOnIncorrectMethodOfRequest(METHOD_GET);
        }
    }
}
