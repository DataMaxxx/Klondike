package test;


import java.io.File;
import java.util.*;

public class Test implements MyInterface {
    public Object some(String s) {
        MyInterface.someInt();
        return new Object();
    }

    public File some(String s, Date date) {
        return new File("");
    }

    public static void main(String[] args) {
        Test test = new Test();

        boolean flag = false;
        boolean flag1 = true;
        Set<Integer> integers = new HashSet<>();
        integers.add(1);
        Map<String, String> map = new HashMap<>();
        map.get("HEllo");
        System.out.println(flag == flag1);
    }
}



