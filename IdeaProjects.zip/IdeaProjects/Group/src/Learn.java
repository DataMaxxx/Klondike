import test.Study;

public class Learn {

    public static void main(String[] args) {
        Study study = new Study();
        Integer integer = new Integer(5);
        String str = "6";//stored in string pool
        String hello = "Hello world";
        String str1 = new String("6");// in heap str = str1
//        String str1 = "6";
//        int [] arr = new int[5];
//        int d = Integer.parseInt(str);
////        Integer integer1 = integer;
//        integer = 6;// new Integer(6)
//        Integer integer1 = null;
//        int a = integer;
//        integer = a;
//        short s;
//        System.out.println(str == str1.intern());
//        System.out.println(str == str1);
        System.out.println(hello.lastIndexOf('o'));
        System.out.println(hello.indexOf('o'));
        System.out.println(hello.substring(6));
        System.out.println(hello.substring(6, 8));
    }
}
