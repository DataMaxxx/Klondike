package learn.inheritance;

import java.io.Closeable;

public class Child extends Man implements Speakable, Cloneable {


    public Child(int count) {
        super(count);
    }

    @Override
    public void printText() {

    }

    @Override
    public void iterate() {

    }

    @Override
    public void funSomeone() {

    }
}
