package Server;

import com.sun.net.httpserver.HttpServer;
import handler.AddUserHandler;
import handler.LevelUserHandler;
import handler.UserHandler;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.net.InetSocketAddress;

/**
 * The class creates http server for handling information about users or levels
 *
 * @author Andrii Valevskyi
 */

public class Server {

    private static final Integer PORT = 9999;
    private static final Integer SOCKET_BACKLOG = 0;
    private static final Logger logger = Logger.getLogger(Server.class);


    public static void main(String[] args) throws IOException {
        HttpServer httpServer = HttpServer.create(new InetSocketAddress(PORT), SOCKET_BACKLOG);
        createContextsForServer(httpServer);
        httpServer.start();
        logger.info("Server is started");
    }

    /**
     * The method provides registration of handlers
     *
     * @param httpServer object of HttpServer
     */

    private static void createContextsForServer(HttpServer httpServer) {
        httpServer.createContext("/userinfo", new UserHandler());
        httpServer.createContext("/levelinfo", new LevelUserHandler());
        httpServer.createContext("/setinfo", new AddUserHandler());
    }

}
