package handler;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import domain.User;
import org.apache.log4j.Logger;
import storage.Storage;

import java.io.IOException;

/**
 * The class is handler for PUT request for saving of user
 */
public class AddUserHandler extends QueryHandler {

    private static final Logger logger = Logger.getLogger(AddUserHandler.class);
    private static final String METHOD_PUT = "PUT";

    @Override
    public void handle(HttpExchange httpExchange) throws IOException {
        setHttpExchange(httpExchange);
        if (validateRequestMethod(METHOD_PUT)) {
            User user = getParametersFromJsonAndCreateUser();
            Storage.saveUser(user);
            String response = "User with id = " + user.getUserId() + " was succefully saved";
            logger.info(response);
            prepareResponse(response);
        } else {
            responseOnIncorrectMethodOfRequest(METHOD_PUT);
        }
    }
}
