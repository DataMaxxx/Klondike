package test;

public class Study {

    private int count;
    private String name;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    protected void print() {
        System.out.println("Hello");
    }

    public static void main(String[] args) {
        Study study = new Study();
        int count = study.count;
    }
}


