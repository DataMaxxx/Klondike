package blocks;

public class Parent {

    static void some(String s) {
        System.out.println("Parent2");
    }

    static void some() {
        System.out.println("Parent1");
    }

    static {
        System.out.println("Static block Parent");
    }

    {
        System.out.println("Not static block Parent");
    }

    public Parent() {
        System.out.println("Constructor Parent");
    }

}
