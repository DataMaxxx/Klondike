package inheritance.mappedsuperclass;

import javax.persistence.*;

@Entity
@Table(name = "DOG")
public class Dog extends Animal {

    private long id;
    private String color;

    public Dog(String color) {
        super("Angry dog");
        this.color = color;
    }

    public Dog() {
    }

    @Column(name = "Color")
    @GeneratedValue
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Id
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public static void main(String[] args) {
        EntityManagerFactory managerFactory = Persistence.createEntityManagerFactory("sample");
        EntityManager entityManager = managerFactory.createEntityManager();
        EntityTransaction transaction = entityManager.getTransaction();
        transaction.begin();
        Dog dog = new Dog("Dark");
        entityManager.persist(dog);
        transaction.commit();
        entityManager.close();
    }

}
