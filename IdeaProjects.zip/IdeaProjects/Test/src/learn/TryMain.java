package learn;

public class TryMain {

    public static final String OS = "Linux";

    enum Seasons {

        WINTER(1, "Winter"), SPRING(2, "Spring");

        private int id;
        private String name;

        Seasons(int id, String name) {
            this.id =  id;
            this.name = name;
        }

        public String getName() {
            return name.concat("Hello");
        }

    }



//    public void count(Integer a) {// new Integer(10)
//        a += 1;
//    }

    public void count(Learn learn) {// new Integer(10)
        learn.getCount();

    }

    public static void main(String[] args) {
        Integer a = new Integer(10);
        TryMain tryMain = new TryMain();
//        tryMain.finalize();
        Learn learn = new Learn(1, "Name");
        learn.getCount();
//        tryMain.count(a);
//        System.out.println(a);
        tryMain.count(learn);

//        System.out.println(learn.getCount());

//        int [][] arr = new int[10][10];

        int[] arr1 = new int[10];


        for (int i = 0; i < arr1.length; ++i) {
            arr1[i] = i * 2 + 1;
        }

//        System.out.println(i);

//        for (int b : arr1) {
//            System.out.print(b + " ");
//        }

//        Seasons season = Seasons.SPRING;
//        System.out.println(season.getName());

        for (Seasons season : Seasons.values()/*Seasons[] season = {WINTER, SPRING}*/) {
            System.out.println(season.getName());
        }



    }
}
