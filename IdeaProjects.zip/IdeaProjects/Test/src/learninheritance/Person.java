package learninheritance;

import learn.Learn;

public class Person {

    private int age;        //has a
    private int height;     //has a
    private String address; //has a

    public Person(int age, int height, String address) {
        this.age = age;
        this.height = height;
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public static void main(String[] args) {
    }
}
