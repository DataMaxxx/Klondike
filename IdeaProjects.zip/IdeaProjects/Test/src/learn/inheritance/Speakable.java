package learn.inheritance;

public interface Speakable extends Funnable {
    public static final int count1 = 10;
    final int count2 = 10;
    static final int count3 = 10;
    int count = 10;

    public abstract void iterate();


//    public abstract void print();
//    abstract void print2();
//    public void print1();
//    void print3();

    default void run() {
        System.out.println("");
    }
}
