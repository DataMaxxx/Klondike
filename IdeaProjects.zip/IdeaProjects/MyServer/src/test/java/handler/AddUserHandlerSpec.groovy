package handler

import com.sun.net.httpserver.Headers
import com.sun.net.httpserver.HttpContext
import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpPrincipal
import spock.lang.Specification


class AddUserHandlerSpec extends Specification {

    InputStream inputStream1
    Headers headers1
    ByteArrayOutputStream arrayOutputStream

    def setup(){
        inputStream1 = new ByteArrayInputStream("{\n \"user_id\": 7,\"level_id\": 1,\"result\": 5\n}".getBytes());
        headers1 = new Headers()
        arrayOutputStream = new ByteArrayOutputStream();
    }

    def "should add user"() {
        setup:
            HttpExchange exchange = getExchange(headers1, inputStream1, arrayOutputStream, "PUT")
        when:
            new AddUserHandler().handle(exchange)
        then:
            Headers headers = exchange.getResponseHeaders()
            exchange.getResponseBody().toString().equals("User with id = 7 was succefully saved")
            headers.get("Content-type").first() == "text/plain"
            exchange.getRequestMethod() == "PUT"
    }

    def "should return error message"() {
        setup:
            HttpExchange exchange = getExchange(headers1, inputStream1, arrayOutputStream, "GET")
        when:
            new AddUserHandler().handle(exchange)
        then:
            Headers headers = exchange.getResponseHeaders()
            exchange.getResponseBody().toString().equals("METHOD OF REQUEST MUST BE PUT")
            headers.get("Content-type").first() == "text/plain"
    }

    private HttpExchange getExchange(headers1, inputStream1, arrayOutputStream, String methodRequest) {
        HttpExchange exchange = new HttpExchange() {
            @Override
            Headers getRequestHeaders() { return null }

            @Override
            Headers getResponseHeaders() {
                return headers1;
            }

            @Override
            URI getRequestURI() { return null }

            @Override
            String getRequestMethod() {
                return methodRequest;
            }

            @Override
            HttpContext getHttpContext() { return null }

            @Override
            void close() {}

            @Override
            InputStream getRequestBody() { return inputStream1; }

            @Override
            OutputStream getResponseBody() { return arrayOutputStream }

            @Override
            void sendResponseHeaders(int i, long l) throws IOException {}

            @Override
            InetSocketAddress getRemoteAddress() { return null }

            @Override
            int getResponseCode() { return 0 }

            @Override
            InetSocketAddress getLocalAddress() { return null }

            @Override
            String getProtocol() { return null }

            @Override
            Object getAttribute(String s) { return null }

            @Override
            void setAttribute(String s, Object o) {}

            @Override
            void setStreams(InputStream inputStream, OutputStream outputStream) {}

            @Override
            HttpPrincipal getPrincipal() { return null }
        };
        exchange
    }
}
