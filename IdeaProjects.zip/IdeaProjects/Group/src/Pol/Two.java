package Pol;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Two extends One {

    public Two(int a) {
        super(a);
    }

    public static void main(String[] args) {

        One one = new One(5);

        int[][] a = {{1, 2, 3}, {4, 5, 6}};
        for (int i = a.length; i != 0; i--) {
            for (int j = a[1].length; j != 0; j--) {
                System.out.println(a[i-1][j-1]);
            }
        }


        }

}
