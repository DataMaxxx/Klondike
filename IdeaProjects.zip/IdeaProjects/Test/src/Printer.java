import sample.Cities;
import sample.Two;

import javax.swing.text.View;

public class Printer extends Two {

    public static final int COUNT = 0;
    public static final String QUERY = "SELECT * FROM Table ";
    public static final String CITY_KIEV = "Kiev";

    enum Country {
        UKRAINE, RUSSIA
    }

    private int count = 8;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public Printer(String s) {
        super("");
    }

    public Printer() {
    }

    public String print(Object string) {
        Printer one = new Printer();
        return "";
    }

    public static void add(Integer i) {//new Integer(5) int i = 5;
        i++; //new Integer(i++)
    }

    public static void add(Printer one) {
        one.count++; //new Integer(i++)
    }


    public static void main(String[] args) {
        Printer one = new Printer();
        String s;
//        Integer i = new Integer(5);
//        Printer.add(i);
        Printer.add(one);
//        System.out.println(one.count);

//        int [] arr = {1,2,3};
//
//        for (int a : arr) {
//            System.out.println(a);
//        }

        Cities cities = Cities.KIEV;
        View view = null;
//        cities.setView(view);
//        cities.addCitizens(500);
//        System.out.println(cities.getCountOfCitizens());
//        System.out.println(cities.getValue());
        Cities[] values = Cities.values();
//        for (Cities city: values) {
//            System.out.println("City " + city.getValue() + " count of citizens = " + city.getCountOfCitizens());
//        }
//        System.out.println(Printer.QUERY + "where table.id = 0");
//        System.out.println(Country.UKRAINE);
//        System.out.println(Printer.CITY_KIEV);
    }

}