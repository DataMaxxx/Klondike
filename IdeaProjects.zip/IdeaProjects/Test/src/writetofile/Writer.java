package writetofile;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Writer {
    public static void main(String[] args) throws IOException {
        String s = "I'm ready to writtting2";
        Path path = FileSystems.getDefault().getPath("../", "MyFile.txt");
        Files.write(path, s.getBytes(), StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.CREATE);
        List<String> strings = Files.readAllLines(path);
//        System.out.println(strings);
        try (BufferedWriter writer = Files.newBufferedWriter(path)) {
            writer.write(s, 0, s.length());

        }
        try (BufferedReader reader = Files.newBufferedReader(path)) {
            String line = null;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        }
    }
}
