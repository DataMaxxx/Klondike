package learn.inheritance;

public abstract class Man {

    private int count;

    public Man(int count) {
        this.count = count;
    }

    public void print() {

    }

    public abstract void printText();

    public static void main(String[] args) {
        Speakable speakable = null;
//        Speakable speakable1 = new Speakable();
//        Man man = new Man();
    }
}
