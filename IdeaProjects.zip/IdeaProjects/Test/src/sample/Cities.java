package sample;

import javax.swing.text.View;

public enum Cities {
    DNEPR("Dnepr", 100), KIEV("Kiev", 200);
    private final View object = null;
    private String value;
    private int countOfCitizens;

    Cities(String value, int count) {
        this.value = value;
        this.countOfCitizens = count;
    }

    public String getValue() {
        return value;
    }

    public int getCountOfCitizens() {
        return countOfCitizens;
    }


    public int addCitizens(int count) {
        countOfCitizens += count;
        return countOfCitizens;
    }

}
