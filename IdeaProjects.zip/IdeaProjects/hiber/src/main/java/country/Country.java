package country;

import inheritance.BigChild;
import inheritance.Man;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


@Entity
@Table(name = "Country_TABLE")
//@TableGenerator(name = "COUNTRY_GEN", table = "ID_TABLE", pkColumnName = "ID_TABLE_NAME",
//        pkColumnValue = "COUNTRY_ID", valueColumnName = "ID_TABLE_VALUE", initialValue = 7, allocationSize = 40)
@SequenceGenerator(name = "COUNTRY_GEN", sequenceName = "COUNTRY_GEN", initialValue = 10, allocationSize = 60)
public class Country implements Serializable {

    @Id
//    @GeneratedValue(strategy=GenerationType.IDENTITY)
//    @GeneratedValue(strategy = GenerationType.AUTO, generator = "COUNTRY_GEN")
//    @GeneratedValue(strategy = GenerationType.TABLE, generator = "COUNTRY_GEN")
//    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "COUNTRY_GEN")
    @GeneratedValue
    @Column(name = "CTRY_ID")
    private Integer id;

    @Column(name = "NameOfCountry")
    private String name;

    @Enumerated(EnumType.ORDINAL)
    private Cities cities;

    @Temporal(TemporalType.TIME)
    private Date date;

    @Transient
    private int countOfCitizens;
    private static int citizens;

    @Embedded
    private City city;

    public Country() {
    }

    public Country(String name) {
        this.name = name;
    }

    public Date getDate() {
        return date;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Cities getCities() {
        return cities;
    }

    public void setCities(Cities cities) {
        this.cities = cities;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static void main(String[] args) {
        EntityManagerFactory managerFactory = Persistence.createEntityManagerFactory("sample");
        EntityManager entityManager = managerFactory.createEntityManager();
        EntityTransaction transaction = entityManager.getTransaction();
        transaction.begin();
//        Man bigChild = new BigChild("Dark");
//        Dog dog = new Dog("Dog");
//        entityManager.persist(dog);
//        entityManager.persist(bigChild);
        City city = new City(100, "Dnepr", State.DNEPR);
        Country country = new Country("Ukraine14");
//        Country country2 = new Country("Ukraine16");
        country.setCities(Cities.DNEPR);
        country.setCity(city);
        country.setDate(new Date());
//        country2.setCity(city);
        entityManager.persist(country);
//        entityManager.persist(country2);
//        Country country1 = entityManager.getReference(Country.class, 1);
//        country.setCities(Cities.PAVLOGRAD);
//        Query query = entityManager.createQuery("SELECT c FROM Country c");
//        List<String> stringList = query.getResultList();
        transaction.commit();
        entityManager.close();
//        stringList.stream().forEach(System.out::println);
//        System.out.println(country1.getDate());
    }
}
