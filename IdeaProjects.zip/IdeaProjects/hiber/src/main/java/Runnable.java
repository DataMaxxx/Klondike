/**
 * Created by andrey on 20.07.16.
 */
public interface Runnable extends Cloneable, java.lang.Runnable {
}
