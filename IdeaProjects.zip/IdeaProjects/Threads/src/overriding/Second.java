package overriding;

import java.io.IOException;

public class Second extends One {

    @Override
    public void print() throws IOException {
    }

    public static void main(String[] args) {
        float f1 = 0.3f;
        float f2 = 0.4f;

//        System.out.println(Math.abs(f1 + f2) > 0.7f);
//        System.out.println((float) 0.7);

    }
}
