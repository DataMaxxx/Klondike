package com.company;

public class Learn {

    public static void main(String[] args) {
       
    }
}
