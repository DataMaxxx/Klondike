package domain;


import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

/**
 * The class is created for storing information about user
 * JsonProperty annotation uses for binding JSON object into User object
 */

public class User implements Serializable {
    @JsonProperty("user_id")
    private int userId;
    @JsonProperty("level_id")
    private int levelId;
    @JsonProperty("result")
    private int result;

    public User() {
    }

    public User(int userId, int levelId, int result) {
        this.userId = userId;
        this.levelId = levelId;
        this.result = result;
    }

    public Integer getUserId() {
        return userId;
    }

    public Integer getLevelId() {
        return levelId;
    }

    public int getResult() {
        return result;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        User user = (User) o;

        if (levelId != user.levelId) return false;
        if (result != user.result) return false;
        if (userId != user.userId) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result1 = userId;
        result1 = 31 * result1 + levelId;
        result1 = 31 * result1 + result;
        return result1;
    }

    @Override
    public String toString() {
        return "User{" +
                "userId=" + userId +
                ", levelId=" + levelId +
                ", result=" + result +
                '}';
    }
}
