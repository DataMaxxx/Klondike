package storage;


import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.IMap;
import domain.User;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * The class is created for storing and handle of information about user
 */

public class Storage {

    private final static int LIMIT_RESULT = 20;

    private static IMap<Integer, Set<User>> storage = Hazelcast.newHazelcastInstance().getMap("user_level");

    /**
     * The method allows to save or update information about users on specific levels
     * @param user user for saving
     */

    public static void saveUser(User user) {
        int levelId = user.getLevelId();
        Set<User> users = new HashSet<>();
        if (storage.containsKey(levelId)) {
            users = storage.get(levelId);
        }
        users.add(user);
        storage.put(levelId, users);
    }

    /**
     * The method allows to sort, limit and cast of the collection
     * @param stream stream of collection
     * @return list of users
     */

    private static List<User> getSortedAndLimitedList(Stream<User> stream) {
        Comparator<User> user_comparator = (user1, user2) -> user2.getResult() - user1.getResult();
        return stream
                .sorted(user_comparator)
                .limit(LIMIT_RESULT)
                .collect(Collectors.toList());
    }

    /**
     * The method allows getting information about specific user on all levels
     * @param userId user id
     * @return list of users
     */

    public static List<User> getUserFromAllLeves(int userId) {
        List<User> filteredUsers = new LinkedList<>();
        storage.values().stream().forEachOrdered(filteredUsers::addAll);
        Stream<User> userStream = filteredUsers.stream().filter(user -> user.getUserId() == userId);
        return getSortedAndLimitedList(userStream);
    }

    /**
     * The method allows getting information about users on specific level
     * @param levelId level id
     * @return list of users
     */

    public static List<User> getUsersFromOneLevel(int levelId) {
        return getSortedAndLimitedList(storage.get(levelId).stream());
    }
}
