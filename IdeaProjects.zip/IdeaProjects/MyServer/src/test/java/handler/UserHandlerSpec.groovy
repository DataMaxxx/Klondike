package handler

import com.sun.net.httpserver.Headers
import com.sun.net.httpserver.HttpContext
import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpPrincipal
import domain.User
import spock.lang.Specification
import storage.Storage


class UserHandlerSpec extends Specification {

    Headers headers1
    ByteArrayOutputStream arrayOutputStream

    def setup(){
        headers1 = new Headers()
        arrayOutputStream = new ByteArrayOutputStream();
    }

    def "should return sorted result of user on all levels"() {
        setup:
            User user = new User(1,3,3)
            User user1 = new User(1,2,5)
            Storage.saveUser(user)
            Storage.saveUser(user1)
            HttpExchange exchange = getExchange(headers1, arrayOutputStream, "GET")
        when:
            new UserHandler().handle(exchange)
        then:
            Headers headers = exchange.getResponseHeaders()
            exchange.getResponseBody().toString().equals("User{userId=1, levelId=2, result=5}\n" +
                                                                            "User{userId=1, levelId=3, result=3}")
            headers.get("Content-type").first() == "text/plain"
            exchange.getRequestMethod() == "GET"
    }

    def "should return error message"() {
        setup:
            HttpExchange exchange = getExchange(headers1, arrayOutputStream, "PUT")
        when:
            new UserHandler().handle(exchange)
        then:
            Headers headers = exchange.getResponseHeaders()
            exchange.getResponseBody().toString().equals("METHOD OF REQUEST MUST BE GET")
            headers.get("Content-type").first() == "text/plain"
    }

    private HttpExchange getExchange(headers1, arrayOutputStream, String requestMethod) {
        HttpExchange exchange = new HttpExchange() {
            @Override
            Headers getRequestHeaders() { return null }

            @Override
            Headers getResponseHeaders() {
                return headers1;
            }

            @Override
            URI getRequestURI() {
                URI uri = new URI()
                uri.query = "1"
                return uri
            }

            @Override
            String getRequestMethod() {
                return requestMethod;
            }

            @Override
            HttpContext getHttpContext() { return null }

            @Override
            void close() {}

            @Override
            InputStream getRequestBody() { return inputStream1; }

            @Override
            OutputStream getResponseBody() { return arrayOutputStream }

            @Override
            void sendResponseHeaders(int i, long l) throws IOException {}

            @Override
            InetSocketAddress getRemoteAddress() { return null }

            @Override
            int getResponseCode() { return 0 }

            @Override
            InetSocketAddress getLocalAddress() { return null }

            @Override
            String getProtocol() { return null }

            @Override
            Object getAttribute(String s) { return null }

            @Override
            void setAttribute(String s, Object o) {}

            @Override
            void setStreams(InputStream inputStream, OutputStream outputStream) {}

            @Override
            HttpPrincipal getPrincipal() { return null }
        };
        exchange
    }
}
