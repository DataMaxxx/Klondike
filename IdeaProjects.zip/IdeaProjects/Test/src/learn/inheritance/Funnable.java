package learn.inheritance;

/**
 * Created by andrey on 26.07.16.
 */
public interface Funnable {
    void funSomeone();
}
