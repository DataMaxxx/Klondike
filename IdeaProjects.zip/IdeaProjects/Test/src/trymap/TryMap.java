package trymap;

import java.util.HashMap;
import java.util.Map;

public class TryMap {

    private String string;
    private int count;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TryMap tryMap = (TryMap) o;

        if (count != tryMap.count) return false;
        return string != null ? string.equals(tryMap.string) : tryMap.string == null;

    }

    @Override
    public int hashCode() {
        int result = string != null ? string.hashCode() : 0;
        result = 31 * result + count;
        return result;
    }

    public static void main(String[] args) {
        Map map = new HashMap();
        TryMap tryMap = new TryMap();
        map.put(tryMap, "Hello");
        TryMap tryMap1 = new TryMap();
        map.put(tryMap1, "Hello");
        System.out.println();
    }
}
