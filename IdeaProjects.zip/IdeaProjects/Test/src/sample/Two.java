package sample;

public class Two {

    String examplerus;







    public Two() {
    }

    public Two(String s) {
    }

    protected Object print(Object o) {
        System.out.println("Hello");
        return "";
    }
}
