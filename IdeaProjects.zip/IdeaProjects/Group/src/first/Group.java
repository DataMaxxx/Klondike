package first;

import java.sql.SQLException;
import java.util.List;

public class Group extends SubGroup {


    public String name;
    private int _id;


    public Group() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void toPage(String s) {
        toPage(s);
    }

//    @Override
//    protected Object convert(String str, List<Integer> list) throws Exception {
//        return new Object();
//    }

    public static void main(String[] args) {
        int[] a = {1, 2, 3};
//        for (int i = a.length; i == 0; i--) {
//            for (int j = a[1].length; j == 0; j--) {
//                System.out.println(a[i][j]);
//            }
//        }
        for (int i = a.length; i > 0; i--) {
            System.out.println(a[i-1]);
        }
        Group group = new Group();
        int id = group._id;
    }
}

class SubGroup {

    public void toPage(String s) {
        try {
            for (; ; ) ;
        } catch (Exception e) {
            System.out.println("Some error");
//        } catch (SQLException sqlException) {
//            System.out.println("Some error");
//        }
        }
    }


    protected String convert(String str, List<Integer> list) throws SQLException {
        return new String();
    }

}
