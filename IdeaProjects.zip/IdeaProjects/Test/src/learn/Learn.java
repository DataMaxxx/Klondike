package learn;

public class Learn {

    private int count;
    private String name;
    private static String nameOfStudent = "Student";

//    {
//        System.out.println("Non static block init.");
//    }
//
//    static {
//        System.out.println("Hello world");
//    }

    public Learn(int count, String name) {
//        System.out.println("Constructor");
        this.count = count;
        this.name = name;
    }

    public static String getNameOfStudent() {
        return nameOfStudent;
    }

    public static void setNameOfStudent(String nameOfStudent) {
        Learn.nameOfStudent = nameOfStudent;
    }

    protected int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public static void main(String[] args) {
        Learn learn = new Learn(1, "Name");//new Learn(this, 1, "Name");, new Learn(learn, 1, "Name");
        Learn learn1 = null;
//        System.out.println(learn1.nameOfStudent);//Learn.nameOfStudent
//        System.out.println(learn1.count);
//        Learn learn1 = new Learn(2, "Name2");
//        learn1.setCount(5);
//        System.out.println(Learn.getNameOfStudent());
        String string = "Name";
        String newString = new String("Name");
        System.out.println(string == newString);
        System.out.println(string == newString.intern());
        System.out.println(string == newString);
    }
}
