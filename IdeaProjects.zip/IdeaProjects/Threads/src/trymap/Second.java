package trymap;

import java.util.HashMap;
import java.util.Map;

public class Second {

    private int id;
    private String name;

    public Second(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

//    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//
//        Second second = (Second) o;
//
//        if (id != second.id) return false;
//        return name.equals(second.name);
//
//    }

    @Override
    public int hashCode() {
//        int result = id;
//        result = 31 * result + name.hashCode();
//        return result;
        return 1;
    }


    public static void main(String[] args) {
        Second second = new Second(1, "Name");
        Second second2 = new Second(1, "Name");

        Map map = new HashMap();
        map.put(second, "Hello1");
        map.put(second2, "Hello2");
        map.entrySet();
    }
}
