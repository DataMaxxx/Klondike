package handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import domain.User;
import org.apache.log4j.Logger;


import java.io.*;
import java.util.List;
import java.util.stream.Collectors;

/**
 * The class is common class for handler classes
 */

public abstract class QueryHandler implements HttpHandler {

    public static final int RESPONSE_STATUS = 200;
    public static final int ERROR_RESPONSE_STATUS = 501;
    public static final String ERROR_MESSAGE = "METHOD OF REQUEST MUST BE ";
    private HttpExchange httpExchange;
    private static final Logger logger = Logger.getLogger(QueryHandler.class);


    public void setHttpExchange(HttpExchange httpExchange) {
        this.httpExchange = httpExchange;
    }

    /*
     * The method provides filling a response header while a user sends incorrect request method
     *
     * @param responseString - string for a error message in response
     * @throws IOException
     */
    protected void responseOnIncorrectMethodOfRequest(String responseString) throws IOException {
        logger.error(ERROR_MESSAGE + responseString);
        fillResponse(ERROR_RESPONSE_STATUS, ERROR_MESSAGE + responseString);
    }

    /**
     * The method provides validation of a request http method
     *
     * @param methodName http method
     * @return true/false if a request is correct/incorrect
     */

    protected boolean validateRequestMethod(String methodName) {
        return httpExchange.getRequestMethod().equals(methodName);
    }

    /**
     * The method provides getting id of a user or a level from a http request
     *
     * @return user or level id
     */

    protected int getParameterFromQuery() {
        String parameter = httpExchange.getRequestURI().getRawQuery();
        return Integer.valueOf(parameter);
    }

    /**
     * The method provides converting a collection to a string with results for response
     *
     * @param users list of users
     * @throws IOException
     */

    protected void convertFromListToStringAndSendResponse(List<User> users) throws IOException {
        String responseString = users.stream()
                .map(Object::toString)
                .collect(Collectors.joining("\n"));
        prepareResponse(responseString);
    }

    /**
     * The method provides to initialization of response object
     *
     * @param responseString string for initialize
     * @throws IOException
     */

    protected void prepareResponse(String responseString) throws IOException {
        fillResponse(RESPONSE_STATUS, responseString);
    }

    private void fillResponse(int status, String responseString) throws IOException {
        Headers responseHeader = httpExchange.getResponseHeaders();
        responseHeader.set("Content-Type", "text/plain");
        httpExchange.sendResponseHeaders(status, responseString.length());
        try (OutputStream os = httpExchange.getResponseBody()) {
            os.write(responseString.getBytes());
        }
    }

    /**
     * The method provides parsing of json object for creating new object of User
     *
     * @return new object of User
     * @throws IOException
     */

    protected User getParametersFromJsonAndCreateUser() throws IOException {
        InputStream inputStream = httpExchange.getRequestBody();
        String collect;
        try (BufferedReader buffer = new BufferedReader(new InputStreamReader(inputStream))) {
            collect = buffer.lines().collect(Collectors.joining("\n"));
        }
        return new ObjectMapper().readValue(collect, User.class);
    }

    @Override
    public abstract void handle(HttpExchange httpExchange) throws IOException;
}
