package handler;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import domain.User;
import org.apache.log4j.Logger;
import storage.Storage;

import java.io.IOException;
import java.util.List;

/**
 * The class is handler for GET request for getting information about user on all levels
 */

public class UserHandler extends QueryHandler {

    public static final String METHOD_GET = "GET";
    private static final Logger logger = Logger.getLogger(UserHandler.class);

    @Override
    public void handle(HttpExchange httpExchange) throws IOException {
        setHttpExchange(httpExchange);
        if (validateRequestMethod(METHOD_GET)) {
            int userId = getParameterFromQuery();
            List<User> userFromAllLeves = Storage.getUserFromAllLeves(userId);
            convertFromListToStringAndSendResponse(userFromAllLeves);
            logger.info("Get user with id = " + userId + " from all levels");
        } else {
            responseOnIncorrectMethodOfRequest(METHOD_GET);
        }
    }
}
