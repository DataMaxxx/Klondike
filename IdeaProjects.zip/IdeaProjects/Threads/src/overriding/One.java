package overriding;

import java.io.IOException;

public class One {

    public void print() throws Exception {
        System.out.println("Hello");
    }

}
