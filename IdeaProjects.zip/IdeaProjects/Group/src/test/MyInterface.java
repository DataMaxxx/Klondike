package test;


public interface MyInterface {
    static void someInt(){

    }
}
