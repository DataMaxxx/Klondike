package learninheritance;

import java.io.Closeable;
import java.io.FileWriter;

public class Student extends Person implements Studyable { //is a
//    private int age;
//    private int height;
//    private String address;
    private int numberGroup;

    @Override
    public void learnBooks() {

    }

    @Override
    public void run() {

    }

    public Student(int age, int height, String address, int numberGroup) {
        super(age, height, address);//call of constructor, new Person
        this.numberGroup = numberGroup;
    }

    public int getNumberGroup() {
        return numberGroup;
    }

    public void setNumberGroup(int numberGroup) {
        this.numberGroup = numberGroup;
    }

    public static void main(String[] args) {
        Student student = new Student(12, 12, "Kiev", 1);
//        System.out.println(student.getAddress());
        Person person = new Student(12, 12, "Pavlograd", 1);
//        Person person1 = new Person(12, 12, "Pavlograd");
        Studyable studyable = new Student(12, 12, "Pavlograd", 5);
        System.out.println(person.getAddress());

    }
}
