package relationship.onetoone;

import javax.persistence.*;
@Entity
@Table(name = "Address")
//@SequenceGenerator(name = "ADDRESS_SEQUENCE", sequenceName = "ADDRESS_SEQUENCE", allocationSize = 1, initialValue = 0)
public class Address {
    @Id
//    @GeneratedValue(strategy = GenerationType.AUTO, generator = "ADDRESS_SEQUENCE")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "Address_name")
    private String name;

    public Address( String name) {
        this.name = name;
    }

    public Address() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
