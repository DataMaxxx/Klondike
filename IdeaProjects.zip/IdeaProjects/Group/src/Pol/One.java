package Pol;


public class One {
    private int a;

    public One(int a) {
        this.a = a;
    }

    void print() {
        Integer y;
        System.out.println(a);
    }

    public static void main(String[] args) {
        One one = new One(5);
        one.print();
    }
}
